﻿using System.Web.UI;

namespace Unt_tutoring_app_test.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}