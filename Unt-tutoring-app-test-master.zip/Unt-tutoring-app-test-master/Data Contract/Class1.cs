﻿namespace Data_Contract
{
    public class Class1
    {

    }
}